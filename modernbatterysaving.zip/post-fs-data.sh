#!/system/bin/sh


# Apply during early boot for maximum effect


# CPU governor tweaks (balanced performance/battery)

echo "conservative" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor


# I/O scheduler tweaks

echo "noop" > /sys/block/sda/queue/scheduler


# Network buffers for mobile data

echo "4096,87380,110208,4096,16384,110208" > /sys/module/tcp_cubic/parameters/tcp_rmem

echo "4096,87380,110208,4096,16384,110208" > /sys/module/tcp_cubic/parameters/tcp_wmem
