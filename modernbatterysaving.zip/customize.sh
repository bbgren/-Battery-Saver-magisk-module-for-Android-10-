#!/system/bin/sh


ui_print " "

ui_print "*******************************"

ui_print " Modern Battery Saver 2024"

ui_print " Android 10+ Optimizations"

ui_print "*******************************"

ui_print " "


set_perm_recursive $MODPATH/system 0 0 0755 0644
