#!/system/bin/sh


while true; do

    # Reduce kernel wakelocks (requires root)

    echo "1" > /sys/module/wakeup/parameters/enable_timerfd_ws

    echo "1" > /sys/module/wakeup/parameters/enable_epoll_ws

    echo "1" > /sys/module/wakeup/parameters/enable_netlink_ws



    # Limit background processes (aggressive)

    setprop ro.sys.fw.bg_apps_limit 12



    # GPU power saving

    echo "4" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel

    echo "4" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel



    sleep 300

done
